
/* */
// Java tutorial
// ArrayList
/* 
import java.util.ArrayList;
import java.util.Collections;

public class wThreeSchool {
    public static void main(String args[]) {
        // for integer
        //ArrayList<Integer> cars = new ArrayList<Integer>();

        ArrayList<String> cars = new ArrayList<String>();
        cars.add("Tesla");
        cars.add("Toato");
        cars.add("nishaan");
        cars.add("TATA");
        // String element = cars.get(2);
        // cars.set(1, "BMW");
        // cars.remove(1);// it should print nishaan as the 
        // list shifts
        // cars.clear(); // to remove all the list element at once
        // Collection.sort(cars)

        System.out.println(cars.size());
        
    }
}
*/
// --------------------------------------------------------------------------------

// HashMap ( dictionary in python)
/* 
import java.util.HashMap;
public class wThreeSchool {
    public static void main(String args[]) {
        HashMap<String, String> capitalCities = 
        new HashMap<String, String>();
        capitalCities.put("England", "London");
        capitalCities.put("Nepal", "Kathmandu");
        capitalCities.put("India", "New Dehli");
        capitalCities.put("Norway", "Oslo");
        capitalCities.put("USA", "Washington DC");
        capitalCities.put("Germany", "Berlin");
        System.out.println(capitalCities);
        // String name = capitalCities.get("Nepal");
        // System.out.println(name);
        // capitalCities.remove("England"); // remove england
        // capitalCities.clear();// remove all
        // capitalCities.size(); // size of the list
        

    }
}
*/
// HashSet same as array list and linked list but it contains unique elements 

// iterator
/* 
import java.util.ArrayList;
import java.util.Iterator;

public class wThreeSchool {
    public static void main(String args[]) {
        ArrayList<String> cars = new ArrayList<String>();

        cars.add("Volvo");
        cars.add("BMW");
        cars.add("Ford");
        cars.add("Mazda");

        Iterator<String> it = cars.iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }
    }
}
*/

//Note: Trying to remove items using a for loop or a for-each loop would not work correctly because the collection is changing size at the same time that the code is trying to loop.

// regular expressions 
/*
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class wThreeSchool {
public static void main(String[] args) {
    Pattern pattern = Pattern.compile("w3schools", Pattern.CASE_INSENSITIVE);
    Matcher matcher = pattern.matcher("Visit W3Schools!");
    boolean matchFound = matcher.find();
    if(matchFound) {
        System.out.println("Match found");
    } else {
        System.out.println("Match not found");
    } 
}
}

 */


/* 
// Java File Handling
import java.io.File;
import java.io.FileWriter;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.IOException;

public class wThreeSchool {
public static void main(String[] args) {
    // creating the file
    try {
        File myObj = new File("Filename.txt");
        // to create file in specific directory.
        // File myObj = new File("C:\\Users\\MyName\\filename.txt"); 
        if(myObj.createNewFile()) {
            System.out.println("File created: " + myObj.getName());

        }
        else{
            System.out.println("File already exists.");
        }
    }
    catch (IOException e) {
        System.out.println("And error occurred.");
        e.printStackTrace();

    }

    // writing in the file 
    try {
        FileWriter myWriter = new FileWriter("filename.txt");
        myWriter.write("File in Java might be tricky, but it is fun enough!");
        myWriter.close();
        System.out.println("Successfully wrote to the file.");

    }
    catch (IOException e) {
        System.out.println("An erroe occurred.");
        e.printStackTrace();
    }
    // reading from the file
    try{
        File myObj = new File("filename.txt");
        Scanner myReader = new Scanner(myObj);
        while(myReader.hasNextLine()) {
            String data = myReader.nextLine();
            System.out.println(data);

        }

        myReader.close();
    }
    catch(FileNotFoundException e){
        System.out.println("An error occurred.");
        e.printStackTrace();

    }

    // delete file

    File myObj = new File("filename.txt");
    if(myObj.delete()) {
        System.out.println("Delted the file: " + myObj.getName());
    }
    else{
        System.out.println("Failed to delete the file.");
    }

}
}

*/
// ----------------------------------------------------------------
/* 
import java.util.Scanner;
// Add two Numbers with user input
public class wThreeSchool {
    public static void main(String args[]) {
        int x, y, sum;
        Scanner sc = new Scanner(System.in);
        System.out.println("Type a number: ");
        x = sc.nextInt();

        System.out.println("Type another number: ");
        y = sc.nextInt();

        sum = x + y;

        System.out.println("The sum of " + x + " and " + y  + " is: " + sum );


        }
    }
    */
/* 
import java.util.Scanner;
// Counting numbers
// did not worked
public class wThreeSchool {
    public static void main(String args[]) {
        String words = "One Two Three Four";
        int countWords = words.split("//s").length;
        System.out.println(countWords);


        }
    }
    */
/* 
import java.util.Scanner;
// Counting numbers
// did not worked
public class wThreeSchool {
    public static void main(String args[]) {
        String orginalStr = "alone";
        String reversedStr = "";

        for(int i = 0; i < orginalStr.length(); i++) {
            reversedStr = orginalStr.charAt(i) + reversedStr;
        }
        System.out.println("Reversed string: " + reversedStr);



        }
    }

    */
/* 
import java.util.Scanner;
// Calculate the Sum of an Array

public class wThreeSchool {
    public static void main(String args[]) {
        int myArray[] = {1, 5, 10, 25};
        int sum = 0;
        int i;

        // loop 
        for (i = 0; i < myArray.length; i++) 
        {
            sum += myArray[i];
        }
        System.out.println("The sum of array is: " + sum);


        }
    }
*/

/* 
import java.util.Scanner;
// Calculate the Area of Rectangle

public class wThreeSchool {
    public static void main(String args[]) {
        int ln = 5, br = 2, area = ln * br;
        System.out.println("Area of rectangle is: " + area);

        


        }
    }
*/


// Check weather a number is odd or even

public class wThreeSchool {
    public static void main(String args[]) {
        int number = 5;

        // find out if the number above is even or odd
        if(number % 2 == 0) {// %  returns the remaining
            System.out.println(number + "is even.");
        }
        else {
            System.out.println(number + "is odd");
        }
        }
    }




