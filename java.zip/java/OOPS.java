
/* 
// Pens
class Pen{
    String color; 
    String type;
    
    public void write() {
        System.out.println("Writing something!!!");
    }
    public void PrintColor() {
        System.out.println(this.color);
    }
}


public class OOPS {
    public static void main(String args[]) {
        Pen pen1 = new Pen();

        pen1.color = "Red";
        pen1.type = "gel pen";

        Pen pen2 = new Pen(); 
        pen2.color = "Blue";
        pen2.type = "ballpoint pen";

        pen1.PrintColor();
        pen2.PrintColor();

    }
}
*/

/*
// student

class Student {
    String name; 
    int age; 

    public void PrintInfo(){
        System.out.println(this.name);
        System.out.println(this.age);   


    }
}

public class OOPS{
    public static void main(String args[]) {
        Student s1 =  new Student();
        s1.name = "Mark";
        s1.age = 17;
        s1.PrintInfo();
        
    }
}
*/

// parameter constructor
/* 
class Student {
    String name; 
    int age; 

    public void PrintInfo(){
        System.out.println(this.name);
        System.out.println(this.age);
    }

    Student(String nam, int umer) {
        this.name = nam; 
        this.age = umer;
    }


}

public class OOPS{
    public static void main(String args[]) {
        Student s1 =  new Student("Nishaan", 17);
        
        s1.PrintInfo();
        
    }
}*/
// copy constructor(understand more)

// polymorphism 
// compiled time 
/* 
class Student {
    String name; 
    int age; 

    public void printInfo(String name) {
        System.out.println(name);


    }
    public void printInfo(int age) {
        System.out.println(age);
        
    }
    public void printInfo(String name, int age) {
        System.out.println(name + " " + age);
        
    }
}
public class OOPS {
    public static void main(String args[]) {
        Student s1 = new Student();
        s1.name = "anam";
        s1.age = 24; 

        s1.printInfo( s1.name);
    }
}
*/
// Inheritance 
// four types
// single  level  inheritance
// multi level inheritance
// hierarchial inheritance
// hybrid inheritance
/* 
class Shape {
    String color; 
    
}
class Triangle extends Shape {

}
class circle extends Shape {

}
class Square extends Triangle {

}
public class OOPS {
    public static void main(String args[]) {
        Triangle t1 = new Triangle();
        t1.color = "red";

    }
}
*/

// encapsulation
// default, public and private
// used for data hiding
// import java.util.*;
// import bank; 

// public class OOPS {
//     public static void main(String args[]) {
//         bank.Account account1 = new bank.Account();
//         account1.name = "customer1";
        
//         System.out.println(account1.name);
//     }
// }

// Abstraction

// abstract class Animal {
//     abstract void walk();
// }

// class Horse extends Animal  {
//     public void walk() {
//         System.out.println("Walks on 4 legs");
//     }

// }

// class Chicken extends Animal {
//     public void walk() {
//         System.out.println("Walks on 2 legs");

//     }
// }

// public class OOPS {
//     public static void main(String args[]) {
//         Horse horse = new Horse();
//         horse.walk();
//         Animal animal = new Animal();
//         animal.walk();
        
//     }
// }

// interface 
interface Animal {
    void walk();
    
}
interface Herbivore {

}
class Horse implements Animal {
    public void walk() {
        System.out.println("Walks on 4 legs");
    }
}

public class OOPS {
    public static void main(String args[]) {
        
    }
}

