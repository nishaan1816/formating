// lecture no 18(Apna college)




// Tower of hanoi 
// Time complexity =O(2^n)
// public class Recursion{
//     public static void towerOfHanoi(int n, String src, String helper, String dest) {
//         if(n == 1) {
//             System.out.println("Transfer disk " + n + " from " + src + " to " + dest);
//             return;
//         }
//         towerOfHanoi(n-1, src, dest, helper);
//         System.out.println("Transfer disk " + n + " from " + src + " to " + dest);
//         towerOfHanoi(n-1,helper, src, dest);
//     }
//     public static void main(String args[]) {
//     int n = 3; 
//     towerOfHanoi(n, "S", "H", "D");
//     }

// }

// -------------------------------------------------------------------------------------------

// Print string in reverse 
// Time complexity =O(n)
// public class Recursion{
//     public static void printRev(String str, int idx) {
//         if(idx == 0) {
//             System.out.print(str.charAt(idx));
//             return;
//         }
//         System.out.print(str.charAt(idx));
//         printRev(str, idx -1 );
//     }
//     public static void main(String args[]) {
//         String str = "abcd";
//         printRev(str, str.length()-1);
//     }

// }

// -------------------------------------------------------------------------------------------

// Find first & last occurrence of element 
// Time complexity =O(n)
// public class Recursion{
//     public static int first = -1; 
//     public static int last = -1; 


//     public static void findOccurance(String str, int idx, char element) {
//         if(idx == str.length()){
//             System.out.println(first);
//             System.out.println(last);
//             return; 
//         }
//         char currChar = str.charAt(idx);
//         if(currChar == element) {
//             if(first == -1)
//             {
//                 first = idx; 
//             }
//             else {
//                 last = idx; 
//             }
            
//         }
//         findOccurance(str, idx +1, element);
        
//     }
//     public static void main(String args[]) {
//         String str = "abaacdaefaah";
//         findOccurance(str, 0, 'a' );
//     }

// }
// -------------------------------------------------------------------------------------------



//Check if an array is sorted ( Strictly increasing )
// time complexity = O(n)


// public class Recursion {
//     public static boolean isSorted(int arr[], int idx) {
//         if(idx == arr.length-1){
//             return true; 
//         }
//         if (arr[idx] < arr[idx+1]){
//             // array is sorted till now
//             return isSorted(arr, idx+1);
//         }
//         else {
//             return false; 
//         }
//     }

//     public static void main(String args[]) {
//         int arr[] = {1,3,5};
//         System.out.println(isSorted(arr, 0));
//     }
// }


// -------------------------------------------------------------------------------------------



// move all 'x' to the end of the string
// TC= O(2n) = O(n)(we don't include 2 for some reason i don't know)
// public class Recursion {
//     public static void moveAllX(String str, int idx, int count, String newString) {
        
//         if ( idx == str.length()) {
//             for(int i = 0; i<count; i++) {
//                 newString += 'x';
//             }
//             System.out.println(newString);
//             return; 

//         }

//         char currChar = str.charAt(idx);
//         if( currChar == 'x') {
//             count++;
//             moveAllX(str, idx+1, count, newString);
//         } else {
//             newString += currChar; 
//             moveAllX(str, idx+1, count, newString);

//         }
//     }
//     public static void main(String args[]){
//         String str = "axbcxxd";
//         moveAllX(str, 0, 0, "");

//     }
// }

// -------------------------------------------------------------------------------------------





// Remove duplicates in a string 
// time complexity = O(n)
// public class Recursion {
//     public static  boolean[] map  = new boolean[26];

//     public static void removeDuplicates(String str, int idx, String newString) {
//         if(idx == str.length()) {
//             System.out.println(newString);
//             return;
//         }

//         char currChar = str.charAt(idx);
//         if (map[currChar - 'a' ] == true) {
//             removeDuplicates(str, idx+1, newString);
//         }
//         else{
//             newString += currChar; 
//             map[currChar - 'a'] = true; 
//             removeDuplicates(str, idx+1, newString);
//         }
//     }
//     public static void main(String args[]) {
//         String str = "abbccda";
//         removeDuplicates(str, 0, " ");

//     }

// }

// -------------------------------------------------------------------------------------------

// Print all the subsequences of a string ( Very important)
// Time complexity = O(2^n)

// public class Recursion{
//     public static void subsequences(String str, int idx, String newString) {
//         if ( idx == str.length()){
//             System.out.println(newString);
//             return; 
//         }
//         char currChar = str.charAt(idx);

//         // to be 
//         subsequences(str, idx+1, newString + currChar);

//         // or not to be 
//         subsequences(str, idx + 1, newString );
//     }

//     public static void main(String args[]) {
//         String str = "abc ";
//         subsequences(str, 0, "");
//     }

// }
// -------------------------------------------------------------------------------------------

// Print all unique subsequences
// Time complexity = O(2^n)

// import java.util.HashSet;

// public class Recursion{
//     public static void subsequences(String str, int idx, String newString, HashSet<String> set) {
//         if ( idx == str.length()){
//             if(set.contains(newString)) {
//                 return;
//             }
//             else {
//                 System.out.println(newString);
//                 set.add(newString);
//                 return; 
//             }
//         }
//         char currChar = str.charAt(idx);

//         // to be 
//         subsequences(str, idx+1, newString + currChar, set);

//         // or not to be 
//         subsequences(str, idx + 1, newString, set);
//     }

//     public static void main(String args[]) {
//         String str = "aaa";
//         HashSet<String> set = new HashSet<>();
//         subsequences(str, 0, "", set);

//     }

// }

// -------------------------------------------------------------------------------------------
// Print Keypad combination
// Time complexity = O(4^n)

// public class Recursion{
//     public static String[] keypad = {".", "abc", "def", "ghi", "jkl", "mno", "pqrs", "tu", "vwx", "yz"};

//         public static void printComb(String str, int idx, String combination) {
//             if(idx == str.length()) {
//                 System.out.println(combination);
//                 return; 
//             }

//             char currChar = str.charAt(idx);
//             String mapping = keypad[currChar - '0'];

//             for(int i = 0; i<mapping.length(); i++) {
//                 printComb(str, idx+1, combination + mapping.charAt(i));
//             }
//         }
//     public static void main(String args[]) {
//         String str = "23";
//         printComb(str, 0, "");

        
//     }

// }


// -------------------------------------------------------------------------------------------
// understand the breakdown of these codes 
