// doing it in leetcode

// Qno-1 :Find the nth node from last + delete nth node
// Qno-2: check wheather a linklist is palimdrome or not ( without using extra space)
// Qno-3: most important question dectating the cycle in linkedList
// removing the cycle is in the notes
